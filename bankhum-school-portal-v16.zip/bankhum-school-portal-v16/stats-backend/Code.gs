const SHEET_NAME = 'Clicks';

function doGet(e) {
  const action = String(e.parameter.action || 'stats');
  if (action === 'click') return logClick_(e);
  return statsJsonp_(e);
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(['Timestamp','SystemID','SystemName','URL']);
    sh.setFrozenRows(1);
  }
  return sh;
}

function logClick_(e) {
  const id = String(e.parameter.id || '').slice(0,120);
  if (!id) return ContentService.createTextOutput('missing id');
  const name = String(e.parameter.name || '').slice(0,250);
  const url = String(e.parameter.url || '').slice(0,1000);
  getSheet_().appendRow([new Date(), id, name, url]);
  return ContentService.createTextOutput('ok');
}

function statsJsonp_(e) {
  const callback = String(e.parameter.callback || 'callback').replace(/[^a-zA-Z0-9_$\.]/g,'');
  const sh = getSheet_();
  const counts = {};
  const lastRow = sh.getLastRow();
  if (lastRow > 1) {
    const values = sh.getRange(2, 2, lastRow - 1, 1).getValues();
    values.forEach(r => {
      const id = String(r[0] || '');
      if (id) counts[id] = (counts[id] || 0) + 1;
    });
  }
  const payload = JSON.stringify({ok:true, counts, updatedAt:new Date().toISOString()});
  return ContentService
    .createTextOutput(`${callback}(${payload});`)
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}
